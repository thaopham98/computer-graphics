#ifndef PREPSHADER_H
#define PREPSHADER_H

int setShader(char* shaderType, char* shaderFile);

#endif
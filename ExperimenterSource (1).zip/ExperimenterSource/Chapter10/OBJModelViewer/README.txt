The OBJ files gourd.obj and lamp.obj thanks to http://people.sc.fsu.edu/~jburkardt/data/obj/obj.html
via a GNU LGPL license.